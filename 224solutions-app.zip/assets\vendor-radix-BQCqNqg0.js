function u(n,t,{checkForDefaultPrevented:a=!0}={}){return function(e){if(n?.(e),a===!1||!e.defaultPrevented)return t?.(e)}}function c(n,[t,a]){return Math.min(a,Math.max(t,n))}export{c as a,u as c};
