import React from 'react';
import SimpleCommunicationInterface from './SimpleCommunicationInterface';

export default function UltraSimpleCommunication() {
  return <SimpleCommunicationInterface />;
}
