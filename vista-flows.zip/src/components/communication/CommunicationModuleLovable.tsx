import React from 'react';
import SimpleCommunicationInterface from './SimpleCommunicationInterface';

export default function CommunicationModuleLovable() {
  return <SimpleCommunicationInterface />;
}
