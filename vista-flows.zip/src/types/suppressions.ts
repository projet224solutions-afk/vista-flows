/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck

// Ce fichier contient les suppressions TypeScript temporaires 
// pour permettre la compilation pendant que nous résolvons les problèmes de typage Supabase

export {};